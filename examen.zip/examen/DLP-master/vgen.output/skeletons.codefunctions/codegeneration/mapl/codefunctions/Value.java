// Generated with VGen 2.0.0

package codegeneration.mapl.codefunctions;

import ast.expression.*;
import codegeneration.mapl.*;


public class Value extends AbstractCodeFunction {

    public Value(MaplCodeSpecification specification) {
        super(specification);
    }


	// class Variable(String name)
	// phase Identification { VarDefinition varDefinition }
	// phase TypeChecking { Type type, boolean lvalue }
	@Override
	public Object visit(Variable variable, Object param) {

		out("<instruction>");

		return null;
	}

	// class FunctionCallExpression(String name, List<Expression> params)
	// phase Identification { FunctionDefinition functionDefinition }
	// phase TypeChecking { Type type, boolean lvalue }
	@Override
	public Object visit(FunctionCallExpression functionCallExpression, Object param) {

		// value(functionCallExpression.params());
		// address(functionCallExpression.params());

		out("<instruction>");

		return null;
	}

	// class IntConstant(String value)
	// phase TypeChecking { Type type, boolean lvalue }
	@Override
	public Object visit(IntConstant intConstant, Object param) {

		out("<instruction>");

		return null;
	}

	// class FloatConstant(String value)
	// phase TypeChecking { Type type, boolean lvalue }
	@Override
	public Object visit(FloatConstant floatConstant, Object param) {

		out("<instruction>");

		return null;
	}

	// class CharConstant(String value)
	// phase TypeChecking { Type type, boolean lvalue }
	@Override
	public Object visit(CharConstant charConstant, Object param) {

		out("<instruction>");

		return null;
	}

	// class ArithmeticExpression(Expression left, String op, Expression right)
	// phase TypeChecking { Type type, boolean lvalue }
	@Override
	public Object visit(ArithmeticExpression arithmeticExpression, Object param) {

		// value(arithmeticExpression.getLeft());
		// address(arithmeticExpression.getLeft());

		// value(arithmeticExpression.getRight());
		// address(arithmeticExpression.getRight());

		out("<instruction>");

		return null;
	}

	// class ComparationExpression(Expression left, String op, Expression right)
	// phase TypeChecking { Type type, boolean lvalue }
	@Override
	public Object visit(ComparationExpression comparationExpression, Object param) {

		// value(comparationExpression.getLeft());
		// address(comparationExpression.getLeft());

		// value(comparationExpression.getRight());
		// address(comparationExpression.getRight());

		out("<instruction>");

		return null;
	}

	// class LogicalExpression(Expression left, String op, Expression right)
	// phase TypeChecking { Type type, boolean lvalue }
	@Override
	public Object visit(LogicalExpression logicalExpression, Object param) {

		// value(logicalExpression.getLeft());
		// address(logicalExpression.getLeft());

		// value(logicalExpression.getRight());
		// address(logicalExpression.getRight());

		out("<instruction>");

		return null;
	}

	// class AccessExpression(Expression left, String right)
	// phase TypeChecking { Type type, boolean lvalue }
	@Override
	public Object visit(AccessExpression accessExpression, Object param) {

		// value(accessExpression.getLeft());
		// address(accessExpression.getLeft());

		out("<instruction>");

		return null;
	}

	// class ArrayExpression(Expression left, Expression right)
	// phase TypeChecking { Type type, boolean lvalue }
	@Override
	public Object visit(ArrayExpression arrayExpression, Object param) {

		// value(arrayExpression.getLeft());
		// address(arrayExpression.getLeft());

		// value(arrayExpression.getRight());
		// address(arrayExpression.getRight());

		out("<instruction>");

		return null;
	}

	// class NotExpression(Expression expression)
	// phase TypeChecking { Type type, boolean lvalue }
	@Override
	public Object visit(NotExpression notExpression, Object param) {

		// value(notExpression.getExpression());
		// address(notExpression.getExpression());

		out("<instruction>");

		return null;
	}

	// class Cast(Type castType, Expression expression)
	// phase TypeChecking { Type type, boolean lvalue }
	@Override
	public Object visit(Cast cast, Object param) {

		// value(cast.getExpression());
		// address(cast.getExpression());

		out("<instruction>");

		return null;
	}

}
