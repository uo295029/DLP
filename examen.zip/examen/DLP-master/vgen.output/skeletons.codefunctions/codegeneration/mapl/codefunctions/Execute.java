// Generated with VGen 2.0.0

package codegeneration.mapl.codefunctions;

import ast.statement.*;
import codegeneration.mapl.*;


public class Execute extends AbstractCodeFunction {

    public Execute(MaplCodeSpecification specification) {
        super(specification);
    }


	// class Assignment(Expression left, Expression right)
	// phase TypeChecking { FunctionDefinition functionDefinition }
	@Override
	public Object visit(Assignment assignment, Object param) {

		// value(assignment.getLeft());
		// address(assignment.getLeft());

		// value(assignment.getRight());
		// address(assignment.getRight());

		out("<instruction>");

		return null;
	}

	// class FunctionCallStatement(String name, List<Expression> params)
	// phase TypeChecking { FunctionDefinition functionDefinition }
	@Override
	public Object visit(FunctionCallStatement functionCallStatement, Object param) {

		// value(functionCallStatement.params());
		// address(functionCallStatement.params());

		out("<instruction>");

		return null;
	}

	// class Print(List<Expression> exp)
	// phase TypeChecking { FunctionDefinition functionDefinition }
	@Override
	public Object visit(Print print, Object param) {

		// value(print.exp());
		// address(print.exp());

		out("<instruction>");

		return null;
	}

	// class Printsp(List<Expression> exp)
	// phase TypeChecking { FunctionDefinition functionDefinition }
	@Override
	public Object visit(Printsp printsp, Object param) {

		// value(printsp.exp());
		// address(printsp.exp());

		out("<instruction>");

		return null;
	}

	// class Println(List<Expression> exp)
	// phase TypeChecking { FunctionDefinition functionDefinition }
	@Override
	public Object visit(Println println, Object param) {

		// value(println.exp());
		// address(println.exp());

		out("<instruction>");

		return null;
	}

	// class Read(Expression expression)
	// phase TypeChecking { FunctionDefinition functionDefinition }
	@Override
	public Object visit(Read read, Object param) {

		// value(read.getExpression());
		// address(read.getExpression());

		out("<instruction>");

		return null;
	}

	// class Return(Optional<Expression> expression)
	// phase TypeChecking { FunctionDefinition functionDefinition }
	@Override
	public Object visit(Return returnValue, Object param) {

		// value(returnValue.getExpression());
		// address(returnValue.getExpression());

		out("<instruction>");

		return null;
	}

	// class If(Expression condition, List<Statement> cierto, List<Statement> falso)
	// phase TypeChecking { FunctionDefinition functionDefinition }
	@Override
	public Object visit(If ifValue, Object param) {

		// value(ifValue.getCondition());
		// address(ifValue.getCondition());

		// execute(ifValue.cierto());

		// execute(ifValue.falso());

		out("<instruction>");

		return null;
	}

	// class While(Expression condition, List<Statement> statements)
	// phase TypeChecking { FunctionDefinition functionDefinition }
	@Override
	public Object visit(While whileValue, Object param) {

		// value(whileValue.getCondition());
		// address(whileValue.getCondition());

		// execute(whileValue.statements());

		out("<instruction>");

		return null;
	}

}
