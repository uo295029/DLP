// Generated with VGen 2.0.0


/*

Este fichero es un esqueleto para facilitar la creación de una clase visitor. Para
usarlo hay que realizar dos pasos:
1. Ubicar este código.
2. Completar cada método visit.

## Paso 1. Ubicación de este Código

Este esqueleto será SOBREESCRITO la próxima vez que se ejecuta VGen. Por ello, se debe
copiar su contenido antes de hacer cualquier cambio.

Hay dos opciones:

1) Si ya se tiene hecha una clase para el visitor, basta con copiar a dicha clase los
   métodos visit de este esqueleto (y los import) ignorando el resto.

2) Si no se tiene hecha aún la clase, este esqueleto vale como tal si se mueve a la
   carpeta deseada del proyecto y se le pone el package correspondiente a dicha ubicación.

Una vez hecho esto, ya se tendría un visitor que compilaría sin errores y que, al
ejecutarlo, recorrería todo el árbol (aunque sin hacer nada en cada nodo).


## Paso 2 Completar cada Método Visit

El visit generado para cada nodo se limita a recorrer sus hijos. El código de recorrido
se encuentra en la llamada a 'super.visit'. Los 'accept' comentados encima de cada
'super.visit' son sólo un recordatorio de lo que hace dicho método (son una copia de su
implementación, que se hereda de DefaultVisitor).

Por tanto, hay tres opciones a la hora de implementar cada visit:

1. Si en el visit de un nodo SÓLO SE NECESITA RECORRER sus hijos, se puede borrar
   completamente dicho visit de esta clase. Al no estar el método, se heredará de
   DefaultVisitor la misma implementación que se acaba de borrar. Es decir, en esta
   clase sólo será necesario dejar los visit que tengan alguna acción que realizar.

2. Si se necesita hacer alguna tarea adicional ANTES o DESPUÉS de recorrer todos
   los hijos, se debe añadir su código antes o después de la llamada a 'super.visit' (y
   se pueden borrar los 'accept' comentados).

3. Y, finalmente, si se necesita hacer alguna tarea INTERCALADA en el recorrido de los
   hijos (por ejemplo, comprobar su tipo), se debe borrar el 'super.visit' y descomentar
   los 'accept'. Así se tendría ya implementado el recorrido de los hijos, que es la
   estructura donde se intecalará el código de las acciones adicionales.

*/

// TODO: write package name
// package ...;

import visitor.DefaultVisitor;
import ast.*;
import ast.definition.*;
import ast.statement.*;
import ast.expression.*;
import ast.type.*;


public class SkeletonForNewVisitors extends DefaultVisitor {

    public void process(AST ast) {
        ast.accept(this, null);
    }

    // Visit Methods --------------------------------------------------------------

	// class Program(List<Definition> definitions)
	@Override
	public Object visit(Program program, Object param) {

		// program.getDefinitions().forEach(definition -> definition.accept(this, param));
		super.visit(program, param);

		return null;
	}

	// class VarDefinition(String name, Type type)
	// phase MemoryAllocation { int offset, int scope }
	@Override
	public Object visit(VarDefinition varDefinition, Object param) {

		// varDefinition.getType().accept(this, param);
		super.visit(varDefinition, param);

		return null;
	}

	// class StructDefinition(String name, List<Field> fields)
	@Override
	public Object visit(StructDefinition structDefinition, Object param) {

		// structDefinition.getFields().forEach(field -> field.accept(this, param));
		super.visit(structDefinition, param);

		return null;
	}

	// class FunctionDefinition(String name, List<VarDefinition> params, Type type, List<VarDefinition> localVars, List<Statement> statements)
	// phase MemoryAllocation { int localVarsSize, int paramsSize }
	@Override
	public Object visit(FunctionDefinition functionDefinition, Object param) {

		// functionDefinition.getParams().forEach(varDefinition -> varDefinition.accept(this, param));
		// functionDefinition.getType().accept(this, param);
		// functionDefinition.getLocalVars().forEach(varDefinition -> varDefinition.accept(this, param));
		// functionDefinition.getStatements().forEach(statement -> statement.accept(this, param));
		super.visit(functionDefinition, param);

		return null;
	}

	// class Assignment(Expression left, Expression right)
	// phase TypeChecking { FunctionDefinition functionDefinition }
	@Override
	public Object visit(Assignment assignment, Object param) {

		// assignment.getLeft().accept(this, param);
		// assignment.getRight().accept(this, param);
		super.visit(assignment, param);

		return null;
	}

	// class FunctionCallStatement(String name, List<Expression> params)
	// phase TypeChecking { FunctionDefinition functionDefinition }
	@Override
	public Object visit(FunctionCallStatement functionCallStatement, Object param) {

		// functionCallStatement.getParams().forEach(expression -> expression.accept(this, param));
		super.visit(functionCallStatement, param);

		return null;
	}

	// class Print(List<Expression> exp)
	// phase TypeChecking { FunctionDefinition functionDefinition }
	@Override
	public Object visit(Print print, Object param) {

		// print.getExp().forEach(expression -> expression.accept(this, param));
		super.visit(print, param);

		return null;
	}

	// class Printsp(List<Expression> exp)
	// phase TypeChecking { FunctionDefinition functionDefinition }
	@Override
	public Object visit(Printsp printsp, Object param) {

		// printsp.getExp().forEach(expression -> expression.accept(this, param));
		super.visit(printsp, param);

		return null;
	}

	// class Println(List<Expression> exp)
	// phase TypeChecking { FunctionDefinition functionDefinition }
	@Override
	public Object visit(Println println, Object param) {

		// println.getExp().forEach(expression -> expression.accept(this, param));
		super.visit(println, param);

		return null;
	}

	// class Read(Expression expression)
	// phase TypeChecking { FunctionDefinition functionDefinition }
	@Override
	public Object visit(Read read, Object param) {

		// read.getExpression().accept(this, param);
		super.visit(read, param);

		return null;
	}

	// class Return(Optional<Expression> expression)
	// phase TypeChecking { FunctionDefinition functionDefinition }
	@Override
	public Object visit(Return returnValue, Object param) {

		// returnValue.getExpression().ifPresent(expression -> expression.accept(this, param));
		super.visit(returnValue, param);

		return null;
	}

	// class If(Expression condition, List<Statement> cierto, List<Statement> falso)
	// phase TypeChecking { FunctionDefinition functionDefinition }
	@Override
	public Object visit(If ifValue, Object param) {

		// ifValue.getCondition().accept(this, param);
		// ifValue.getCierto().forEach(statement -> statement.accept(this, param));
		// ifValue.getFalso().forEach(statement -> statement.accept(this, param));
		super.visit(ifValue, param);

		return null;
	}

	// class While(Expression condition, List<Statement> statements)
	// phase TypeChecking { FunctionDefinition functionDefinition }
	@Override
	public Object visit(While whileValue, Object param) {

		// whileValue.getCondition().accept(this, param);
		// whileValue.getStatements().forEach(statement -> statement.accept(this, param));
		super.visit(whileValue, param);

		return null;
	}

	// class Variable(String name)
	// phase Identification { VarDefinition varDefinition }
	// phase TypeChecking { Type type, boolean lvalue }
	@Override
	public Object visit(Variable variable, Object param) {

		return null;
	}

	// class FunctionCallExpression(String name, List<Expression> params)
	// phase Identification { FunctionDefinition functionDefinition }
	// phase TypeChecking { Type type, boolean lvalue }
	@Override
	public Object visit(FunctionCallExpression functionCallExpression, Object param) {

		// functionCallExpression.getParams().forEach(expression -> expression.accept(this, param));
		super.visit(functionCallExpression, param);

		return null;
	}

	// class IntConstant(String value)
	// phase TypeChecking { Type type, boolean lvalue }
	@Override
	public Object visit(IntConstant intConstant, Object param) {

		return null;
	}

	// class FloatConstant(String value)
	// phase TypeChecking { Type type, boolean lvalue }
	@Override
	public Object visit(FloatConstant floatConstant, Object param) {

		return null;
	}

	// class CharConstant(String value)
	// phase TypeChecking { Type type, boolean lvalue }
	@Override
	public Object visit(CharConstant charConstant, Object param) {

		return null;
	}

	// class ArithmeticExpression(Expression left, String op, Expression right)
	// phase TypeChecking { Type type, boolean lvalue }
	@Override
	public Object visit(ArithmeticExpression arithmeticExpression, Object param) {

		// arithmeticExpression.getLeft().accept(this, param);
		// arithmeticExpression.getRight().accept(this, param);
		super.visit(arithmeticExpression, param);

		return null;
	}

	// class ComparationExpression(Expression left, String op, Expression right)
	// phase TypeChecking { Type type, boolean lvalue }
	@Override
	public Object visit(ComparationExpression comparationExpression, Object param) {

		// comparationExpression.getLeft().accept(this, param);
		// comparationExpression.getRight().accept(this, param);
		super.visit(comparationExpression, param);

		return null;
	}

	// class LogicalExpression(Expression left, String op, Expression right)
	// phase TypeChecking { Type type, boolean lvalue }
	@Override
	public Object visit(LogicalExpression logicalExpression, Object param) {

		// logicalExpression.getLeft().accept(this, param);
		// logicalExpression.getRight().accept(this, param);
		super.visit(logicalExpression, param);

		return null;
	}

	// class AccessExpression(Expression left, String right)
	// phase TypeChecking { Type type, boolean lvalue }
	@Override
	public Object visit(AccessExpression accessExpression, Object param) {

		// accessExpression.getLeft().accept(this, param);
		super.visit(accessExpression, param);

		return null;
	}

	// class ArrayExpression(Expression left, Expression right)
	// phase TypeChecking { Type type, boolean lvalue }
	@Override
	public Object visit(ArrayExpression arrayExpression, Object param) {

		// arrayExpression.getLeft().accept(this, param);
		// arrayExpression.getRight().accept(this, param);
		super.visit(arrayExpression, param);

		return null;
	}

	// class NotExpression(Expression expression)
	// phase TypeChecking { Type type, boolean lvalue }
	@Override
	public Object visit(NotExpression notExpression, Object param) {

		// notExpression.getExpression().accept(this, param);
		super.visit(notExpression, param);

		return null;
	}

	// class Cast(Type castType, Expression expression)
	// phase TypeChecking { Type type, boolean lvalue }
	@Override
	public Object visit(Cast cast, Object param) {

		// cast.getCastType().accept(this, param);
		// cast.getExpression().accept(this, param);
		super.visit(cast, param);

		return null;
	}

	// class Field(String name, Type fieldType)
	// phase MemoryAllocation { int offset }
	@Override
	public Object visit(Field field, Object param) {

		// field.getFieldType().accept(this, param);
		super.visit(field, param);

		return null;
	}

	// class IntType()
	// phase MemoryAllocation { String suffix }
	@Override
	public Object visit(IntType intType, Object param) {

		return null;
	}

	// class FloatType()
	// phase MemoryAllocation { String suffix }
	@Override
	public Object visit(FloatType floatType, Object param) {

		return null;
	}

	// class CharType()
	// phase MemoryAllocation { String suffix }
	@Override
	public Object visit(CharType charType, Object param) {

		return null;
	}

	// class VoidType()
	// phase MemoryAllocation { String suffix }
	@Override
	public Object visit(VoidType voidType, Object param) {

		return null;
	}

	// class StructType(String name)
	// phase Identification { StructDefinition structDefinition }
	// phase MemoryAllocation { String suffix }
	@Override
	public Object visit(StructType structType, Object param) {

		return null;
	}

	// class ArrayType(int size, Type type)
	// phase MemoryAllocation { String suffix }
	@Override
	public Object visit(ArrayType arrayType, Object param) {

		// arrayType.getType().accept(this, param);
		super.visit(arrayType, param);

		return null;
	}

}
