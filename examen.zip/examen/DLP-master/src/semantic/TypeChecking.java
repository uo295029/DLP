/**
 * MLang. Programming Language Design Tutorial
 * @author Raúl Izquierdo (raul@uniovi.es)
 */

package semantic;

import ast.*;
import ast.definition.FunctionDefinition;
import ast.definition.VarDefinition;
import ast.expression.*;
import ast.statement.*;
import ast.type.*;
import main.ErrorManager;
import visitor.DefaultVisitor;

// This class will be implemented in type checking phase

public class TypeChecking extends DefaultVisitor {

    private ErrorManager errorManager;

    public TypeChecking(ErrorManager errorManager) {
        this.errorManager = errorManager;
    }

    public void process(AST ast) {
        ast.accept(this, null);
    }

    // # ----------------------------------------------------------
    /*
    * Implement visit methods here.
    */

    @Override
    public Object visit(Assignment assignment, Object param) {
        super.visit(assignment,param);
        predicate(sameType(assignment.getLeft().getType(),assignment.getRight().getType())
                , "Types of expressions in Assignment must be equals", assignment);
        predicate(simpleType(assignment.getLeft().getType())
                , "Left expression type must be simple type", assignment); //Revisar
        predicate(assignment.getLeft().isLvalue(), "Left expression should be LValue", assignment);
        return null;
    }

    @Override
    public Object visit(Variable variable, Object param) {
        variable.setType(variable.getVarDefinition().getType());
        variable.setLvalue(true);
        return null;
    }

    @Override
    public Object visit(VarDefinition varDefinition, Object param) {
        super.visit(varDefinition,param);
        if (varDefinition.getScope() == 1) {
            predicate(simpleType(varDefinition.getType()), "Parameter type must be simple type", varDefinition);
        }
        return null;
    }

    @Override
    public Object visit(FunctionDefinition functionDefinition, Object param) {
        functionDefinition.getParams().forEach(varDefinition -> varDefinition.accept(this, param));
        functionDefinition.getType().accept(this, param);
        functionDefinition.getLocalVars().forEach(varDefinition -> varDefinition.accept(this, param));
        functionDefinition.getStatements().forEach(statement -> statement.accept(this, param));
        predicate(simpleType(functionDefinition.getType()) || (functionDefinition.getType() instanceof VoidType)
                , "Return type must be simple type or void", functionDefinition);
        return null;
    }

    @Override
    public Object visit(FunctionCallExpression functionCallExpression, Object param) {
        super.visit(functionCallExpression,param);
        predicate(simpleType(functionCallExpression.getFunctionDefinition().getType())
                , "Function must returns a simple type expression", functionCallExpression);
        predicate(sameSize(functionCallExpression.getParams().size()
                        ,functionCallExpression.getFunctionDefinition().getParams().size())
                , "Function call must have "
                        + functionCallExpression.getFunctionDefinition().getParams().size()
                        + " arguments", functionCallExpression);
        if (sameSize(functionCallExpression.getFunctionDefinition().getParams().size()
                , functionCallExpression.getParams().size())) {
            for (int i = 0; i < functionCallExpression.getParams().size(); i++) {
                predicate(sameType(functionCallExpression.getParams().get(i).getType(),
                        functionCallExpression.getFunctionDefinition().getParams().get(i).getType())
                        ,"Param in position " + (i+1) + " must be " +
                                functionCallExpression.getFunctionDefinition().getParams().get(i).getType()
                        , functionCallExpression);
            }
        }
        functionCallExpression.setType(functionCallExpression.getFunctionDefinition().getType());
        functionCallExpression.setLvalue(false);
        return null;
    }

    @Override
    public Object visit(FunctionCallStatement functionCallStatement, Object param) {
        super.visit(functionCallStatement,param);
        predicate(sameSize(functionCallStatement.getParams().size()
                        ,functionCallStatement.getFunctionDefinition().getParams().size())
                , "Function call must have "
                        + functionCallStatement.getFunctionDefinition().getParams().size()
                        + " arguments", functionCallStatement);
        if (sameSize(functionCallStatement.getFunctionDefinition().getParams().size()
                , functionCallStatement.getParams().size())) {
            for (int i = 0; i < functionCallStatement.getParams().size(); i++) {
                predicate(sameType(functionCallStatement.getParams().get(i).getType(),
                                functionCallStatement.getFunctionDefinition().getParams().get(i).getType())
                        ,"Param in position " + (i+1) + " must be " +
                                functionCallStatement.getFunctionDefinition().getParams().get(i).getType()
                        , functionCallStatement);
            }
        }
        return null;
    }

    @Override
    public Object visit(IntConstant intConstant, Object param) {
        intConstant.setType(new IntType());
        intConstant.setLvalue(false);
        return null;
    }

    @Override
    public Object visit(FloatConstant floatConstant, Object param) {
        floatConstant.setType(new FloatType());
        floatConstant.setLvalue(false);
        return null;
    }

    @Override
    public Object visit(CharConstant charConstant, Object param) {
        charConstant.setType(new CharType());
        charConstant.setLvalue(false);
        return null;
    }

    @Override
    public Object visit(ArithmeticExpression arithmeticExpression, Object param) {
        super.visit(arithmeticExpression,param);
        predicate(sameType(arithmeticExpression.getLeft().getType(), arithmeticExpression.getRight().getType())
                , "Types of expressions in ArithmeticExpression must be equals", arithmeticExpression);
        if (arithmeticExpression.getOp().equals("%")) {
            predicate(intType(arithmeticExpression.getLeft().getType())
                    && intType(arithmeticExpression.getRight().getType())
                    , "Both operands must be int type", arithmeticExpression);
        }
        else {
            predicate(numberType(arithmeticExpression.getLeft().getType())
                            && numberType(arithmeticExpression.getRight().getType())
                    , "Both operands must be int type or float type", arithmeticExpression);
        }
        arithmeticExpression.setType(arithmeticExpression.getLeft().getType());
        arithmeticExpression.setLvalue(false);
        return null;
    }

    @Override
    public Object visit(ComparationExpression comparationExpression, Object param) {
        super.visit(comparationExpression, param);
        predicate(sameType(comparationExpression.getLeft().getType(), comparationExpression.getRight().getType())
                , "Types of expressions in ComparationExpression must be equals", comparationExpression);
        predicate(numberType(comparationExpression.getLeft().getType())
                , "Type of ComparationExpression must be IntType or FloatType", comparationExpression);
        comparationExpression.setType(new IntType());
        comparationExpression.setLvalue(false);
        return null;
    }

    @Override
    public Object visit(LogicalExpression logicalExpression, Object param) {
        super.visit(logicalExpression,param);
        predicate(sameType(logicalExpression.getLeft().getType(), logicalExpression.getRight().getType())
                , "Types of expressions in LogicalExpression must be equals", logicalExpression);
        predicate(intType(logicalExpression.getLeft().getType())
                , "Type of LogicalExpression must be IntType", logicalExpression);
        logicalExpression.setType(logicalExpression.getLeft().getType());
        logicalExpression.setLvalue(false);
        return null;
    }

    @Override
    public Object visit(NotExpression notExpression, Object param) {
        super.visit(notExpression,param);
        predicate(intType(notExpression.getExpression().getType())
                , "Type of expression must be IntType", notExpression);
        notExpression.setType(notExpression.getExpression().getType());
        notExpression.setLvalue(false);
        return null;
    }

    @Override
    public Object visit(AccessExpression accessExpression, Object param) {
        super.visit(accessExpression, param);
        predicate(accessExpression.getLeft().getType() instanceof StructType
                , "Left expression should be Struct Type ", accessExpression);
        if (accessExpression.getLeft().getType() instanceof StructType st_type) {
            predicate(st_type.getStructDefinition().getFieldsNames().contains(accessExpression.getRight())
                    , "Field " + accessExpression.getRight() + " doesn't exists in Struct " +
                    st_type.getName(), accessExpression);
            if (st_type.getStructDefinition().getFieldsNames().contains(accessExpression.getRight())) {
                accessExpression.setType(st_type.getStructDefinition().getField(accessExpression.getRight()).getFieldType());
            }
        }
        accessExpression.setLvalue(true);
        return null;
    }

    @Override
    public Object visit(ArrayExpression arrayExpression, Object param) {
        super.visit(arrayExpression, param);
        predicate(arrayExpression.getLeft().getType() instanceof ArrayType
                , "Left expression should be ArrayType", arrayExpression);
        predicate(intType(arrayExpression.getRight().getType())
                , "Size of array must be IntType", arrayExpression);
        if (arrayExpression.getLeft().getType() instanceof ArrayType arrayType) {
            arrayExpression.setType(arrayType.getType());
        }
        arrayExpression.setLvalue(true);
        return null;
    }

    @Override
    public Object visit(Cast cast, Object param) {
        super.visit(cast,param);
        predicate(simpleType(cast.getCastType())
                , "Type of cast must be simple type", cast);
        predicate(simpleType(cast.getExpression().getType())
                , "Type of expression in Cast must be simple type", cast);
        predicate(!sameType(cast.getExpression().getType(), cast.getCastType())
                , "Types of expressions in Cast must be different", cast);
        cast.setType(cast.getCastType());
        cast.setLvalue(false);
        return null;
    }

    @Override
    public Object visit(Return returnExp, Object param) {
        super.visit(returnExp, param);
        if(!(returnExp.getFunctionDefinition().getType() instanceof VoidType)) {
            predicate(returnExp.getExpression().isPresent(), "Expression in return can't be null or empty"
                    , returnExp);
            if (returnExp.getExpression().isPresent())
                predicate(sameType(returnExp.getExpression().get().getType(), returnExp.getFunctionDefinition().getType())
                        , "Type of return must be equal to type in function definition", returnExp);
        }
        else {
            predicate(returnExp.getExpression().isEmpty()
                    , "Return must be empty in Void Type Function", returnExp);
        }

        return null;
    }

    @Override
    public Object visit(Print print, Object param) {
        super.visit(print,param);
        for(Expression exp : print.getExp()) {
            predicate(simpleType(exp.getType()), "Expression in print must be simple type", print);
        }
        return null;
    }

    @Override
    public Object visit(Printsp printsp, Object param) {
        super.visit(printsp,param);
        for(Expression exp : printsp.getExp()) {
            predicate(simpleType(exp.getType()), "Expression in printsp must be simple type", printsp);
        }
        return null;
    }

    @Override
    public Object visit(Println println, Object param) {
        super.visit(println,param);
        for(Expression exp : println.getExp()) {
            predicate(simpleType(exp.getType()), "Expression in println must be simple type", println);
        }
        return null;
    }

    @Override
    public Object visit(Read read, Object param) {
        super.visit(read,param);
        predicate(simpleType(read.getExpression().getType()), "Expression in read must be simple type", read);
        predicate(read.getExpression().isLvalue(), "Expression in read must be lValue", read);
        return null;
    }

    @Override
    public Object visit(If ifStatement, Object param) {
        super.visit(ifStatement,param);
        predicate(intType(ifStatement.getCondition().getType())
                , "Condition must be int type", ifStatement);
        return null;
    }

    @Override
    public Object visit(While whileStatement, Object param) {
        super.visit(whileStatement,param);
        predicate(intType(whileStatement.getCondition().getType())
                , "Condition must be int type", whileStatement);
        return null;
    }




    // public Object visit(Program prog, Object param) {
    //      ...
    // }

    // ...
    // ...
    // ...

    //# ----------------------------------------------------------
    //# Auxiliary methods (optional)

    private void notifyError(String errorMessage, Position position) {
        errorManager.notify("Type Checking", errorMessage, position);
    }

    private void notifyError(String msg) {
        errorManager.notify("Type Checking", msg);
    }

    /**
     * predicate. Auxiliary method to implement predicates. Delete if not needed.
     *
     * Usage examples:
     *
     *    predicate(expr.type != null), "Type cannot be null", expr.start());
     *
     *    predicate(expr.type != null), "Type cannot be null", expr);       // expr.start() is assumed
     *
     * The start() method (example 1) indicates the position in the file where the node was. If VGen is used, this method
     * will have been generated in all AST nodes.
     *
     * @param condition     Must be met to avoid an error
     * @param errorMessage  Printed if the condition is not met
     * @return true if the condition is met
     */

    private boolean predicate(boolean condition, String errorMessage, Position position) {
        if (!condition) {
            notifyError(errorMessage, position);
            return false;
        }

        return true;
    }

    private boolean predicate(boolean condition, String errorMessage, AST node) {
        return predicate(condition, errorMessage, node.start());
    }

    private boolean sameType(Type a, Type b) {
        return a.toString().equals(b.toString());
    }

    private boolean sameSize(int a, int b) {
        return a == b;
    }

    private boolean simpleType(Type type) {
        return type instanceof IntType || type instanceof FloatType || type instanceof CharType;
    }

    private boolean numberType(Type type) {
        return type instanceof IntType || type instanceof FloatType;
    }

    private boolean intType(Type type) {
        return type instanceof IntType;
    }

}
