package semantic;

import ast.*;
import ast.definition.Definition;
import ast.definition.FunctionDefinition;
import ast.definition.StructDefinition;
import ast.definition.VarDefinition;
import ast.expression.FunctionCallExpression;
import ast.expression.Variable;
import ast.statement.*;
import ast.type.StructType;
import main.ErrorManager;
import visitor.DefaultVisitor;

// This class will be implemented in identification phase

public class Identification extends DefaultVisitor {

    private ErrorManager errorManager;
    ContextMap<VarDefinition> varDefinitions = new ContextMap<VarDefinition>();
    ContextMap<FunctionDefinition> funcDefinitions = new ContextMap<FunctionDefinition>();
    ContextMap<StructDefinition> structDefinitions = new ContextMap<StructDefinition>();

    public Identification(ErrorManager errorManager) {
        this.errorManager = errorManager;
    }

    public void process(AST ast) {
        ast.accept(this, null);
    }

    // # ----------------------------------------------------------
    /*
     * Write "visits" here...
     */
    @Override
    public Object visit(VarDefinition varDefinition, Object param) {
        super.visit(varDefinition,param);
        if (varDefinition.getScope() != 1 && varDefinition.getScope() != 2) {
            varDefinition.setScope(0);
        }
        var definition = varDefinitions.getFromTop(varDefinition.getName());
        if (definition != null)
            notifyError("Variable already defined: " + varDefinition.getName(), varDefinition);
        else
            varDefinitions.put(varDefinition.getName(), varDefinition);
        return null;
    }

    @Override
    public Object visit(Variable var, Object param) {
        var definition = varDefinitions.getFromAny(var.getName());
        if (definition == null)
            notifyError("Variable not defined: " + var.getName(), var);
        else {
            var.setVarDefinition(definition);
        }
        return null;
    }

    @Override
    public Object visit(FunctionDefinition functionDefinition, Object param) {
        var definition = funcDefinitions.getFromAny(functionDefinition.getName());
        if (definition != null)
            notifyError("Function already defined: " + functionDefinition.getName(), functionDefinition);
        else
            funcDefinitions.put(functionDefinition.getName(), functionDefinition);
        varDefinitions.set();
        functionDefinition.getParams().forEach(varDefinition -> {
            varDefinition.setScope(1);
            varDefinition.accept(this, param);
        });
        functionDefinition.getType().accept(this, param);
        functionDefinition.getLocalVars().forEach(varDefinition -> {
            varDefinition.setScope(2);
            varDefinition.accept(this, param);
        });
        functionDefinition.getStatements().forEach(statement -> statement.accept(this, functionDefinition));
        varDefinitions.reset();
        return null;
    }

    @Override
    public Object visit(If ifStatement, Object param) {
        super.visit(ifStatement,param);
        ifStatement.setFunctionDefinition((FunctionDefinition) param);
        return null;
    }

    @Override
    public Object visit(Return retStatement, Object param) {
        super.visit(retStatement,param);
        retStatement.setFunctionDefinition((FunctionDefinition) param);
        return null;
    }

    @Override
    public Object visit(Print printSt, Object param) {
        super.visit(printSt,param);
        printSt.setFunctionDefinition((FunctionDefinition) param);
        return null;
    }

    @Override
    public Object visit(Println printlnSt, Object param) {
        super.visit(printlnSt,param);
        printlnSt.setFunctionDefinition((FunctionDefinition) param);
        return null;
    }

    @Override
    public Object visit(Printsp printSpSt, Object param) {
        super.visit(printSpSt,param);
        printSpSt.setFunctionDefinition((FunctionDefinition) param);
        return null;
    }

    @Override
    public Object visit(Assignment assignment, Object param) {
        super.visit(assignment,param);
        assignment.setFunctionDefinition((FunctionDefinition) param);
        return null;
    }

    @Override
    public Object visit(Read read, Object param) {
        super.visit(read,param);
        read.setFunctionDefinition((FunctionDefinition) param);
        return null;
    }

    @Override
    public Object visit(While whileStatement, Object param) {
        super.visit(whileStatement,param);
        whileStatement.setFunctionDefinition((FunctionDefinition) param);
        return null;
    }

    @Override
    public Object visit(FunctionCallExpression functionCallExpression, Object param) {
        var definition = funcDefinitions.getFromAny(functionCallExpression.getName());
        if (definition == null)
            notifyError("Function not defined: " + functionCallExpression.getName(), functionCallExpression);
        super.visit(functionCallExpression,param);
        functionCallExpression.setFunctionDefinition(definition);
        return null;
    }

    @Override
    public Object visit(FunctionCallStatement functionCallStatement, Object param) {
        var definition = funcDefinitions.getFromAny(functionCallStatement.getName());
        if (definition == null)
            notifyError("Function not defined: " + functionCallStatement.getName(), functionCallStatement);
        super.visit(functionCallStatement,param);
        functionCallStatement.setFunctionDefinition(definition);
        return null;
    }

    @Override
    public Object visit(StructDefinition structDefinition, Object param) {
        var definition = structDefinitions.getFromAny(structDefinition.getName());
        if (definition != null)
            notifyError("Struct already defined: " + structDefinition.getName(), structDefinition);
        else
            structDefinitions.put(structDefinition.getName(), structDefinition);
        varDefinitions.set();
        super.visit(structDefinition,param);
        varDefinitions.reset();
        return null;
    }

     @Override
     public Object visit(StructType structType, Object param) {
         var definition = structDefinitions.getFromAny(structType.getName());
         if (definition == null)
             notifyError("Struct not defined: " + structType.getName(), structType);
         structType.setStructDefinition(definition);
         return null;
     }


    // public Object visit(Program prog, Object param) {
    //      ...
    // }

    // ...
    // ...
    // ...

    // # --------------------------------------------------------
    // Métodos auxiliares recomendados (opcionales) -------------

    private void notifyError(String msg) {
        errorManager.notify("Identification", msg);
    }

    private void notifyError(String msg, Position position) {
        errorManager.notify("Identification", msg, position);
    }

    private void notifyError(String msg, AST node) {
        notifyError(msg, node.start());
    }

}
