// Generated with VGen 2.0.0

package ast;

import ast.type.*;
import org.antlr.v4.runtime.Token;
import visitor.Visitor;

// %% User Declarations -------------

    // Declarations (e.g. imports) in this section will be preserved. Delete if not needed

// %% -------------------------------

/*
	field -> name:string fieldType:type
	
	PHASE MemoryAllocation
	field -> offset:int
*/
public class Field extends AbstractAST  {

    // ----------------------------------
    // Instance Variables

	// field -> name:string fieldType:type
	private String name;
	private Type fieldType;

    // PHASE MemoryAllocation
	private int offset;

    // ----------------------------------
    // Constructors

	public Field(String name, Type fieldType) {
		super();

		if (name == null)
			throw new IllegalArgumentException("Parameter 'name' can't be null. Pass a non-null value or use 'string?' in the abstract grammar");
		this.name = name;

		if (fieldType == null)
			throw new IllegalArgumentException("Parameter 'fieldType' can't be null. Pass a non-null value or use 'type?' in the abstract grammar");
		this.fieldType = fieldType;

		updatePositions(name, fieldType);
	}

	public Field(Object name, Object fieldType) {
		super();

        if (name == null)
            throw new IllegalArgumentException("Parameter 'name' can't be null. Pass a non-null value or use 'string?' in the abstract grammar");
		this.name = (name instanceof Token) ? ((Token) name).getText() : (String) name;

        if (fieldType == null)
            throw new IllegalArgumentException("Parameter 'fieldType' can't be null. Pass a non-null value or use 'type?' in the abstract grammar");
		this.fieldType = (Type) fieldType;

		updatePositions(name, fieldType);
	}


    // ----------------------------------
    // field -> name:string fieldType:type

	// Child 'name:string' 

	public void setName(String name) {
		if (name == null)
			throw new IllegalArgumentException("Parameter 'name' can't be null. Pass a non-null value or use 'string?' in the abstract grammar");
		this.name = name;

	}

    public String getName() {
        return name;
    }


	// Child 'fieldType:type' 

	public void setFieldType(Type fieldType) {
		if (fieldType == null)
			throw new IllegalArgumentException("Parameter 'fieldType' can't be null. Pass a non-null value or use 'type?' in the abstract grammar");
		this.fieldType = fieldType;

	}

    public Type getFieldType() {
        return fieldType;
    }



    // --------------------------------
    // PHASE MemoryAllocation

	// Attribute 'offset:int' 

	public void setOffset(int offset) {
		this.offset = offset;

	}

    public int getOffset() {
        return offset;
    }


    // ----------------------------------
    // Helper methods

    @Override
    public Object accept(Visitor v, Object param) {
        return v.visit(this, param);
    }

    @Override
    public String toString() {
        return "Field{" + " name=" + this.getName() + " fieldType=" + this.getFieldType() + "}";
    }


    // %% User Members -------------------------

        // Methods/attributes in this section will be preserved. Delete if not needed

    // %% --------------------------------------
}
