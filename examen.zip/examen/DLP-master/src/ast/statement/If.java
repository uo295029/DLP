// Generated with VGen 2.0.0

package ast.statement;

import ast.expression.*;
import ast.definition.*;
import java.util.List;
import java.util.ArrayList;
import java.util.stream.Stream;
import visitor.Visitor;

// %% User Declarations -------------

    // Declarations (e.g. imports) in this section will be preserved. Delete if not needed

// %% -------------------------------

/*
	If: statement -> condition:expression cierto:statement* falso:statement*
	statement -> 
	
	PHASE TypeChecking
	statement -> functionDefinition:functionDefinition
*/
public class If extends AbstractStatement  {

    // ----------------------------------
    // Instance Variables

	// If: statement -> condition:expression cierto:statement* falso:statement*
	private Expression condition;
	private List<Statement> cierto;
	private List<Statement> falso;

    // ----------------------------------
    // Constructors

	public If(Expression condition, List<Statement> cierto, List<Statement> falso) {
		super();

		if (condition == null)
			throw new IllegalArgumentException("Parameter 'condition' can't be null. Pass a non-null value or use 'expression?' in the abstract grammar");
		this.condition = condition;

		if (cierto == null)
			cierto = new ArrayList<>();
		this.cierto = cierto;

		if (falso == null)
			falso = new ArrayList<>();
		this.falso = falso;

		updatePositions(condition, cierto, falso);
	}

	public If(Object condition, Object cierto, Object falso) {
		super();

        if (condition == null)
            throw new IllegalArgumentException("Parameter 'condition' can't be null. Pass a non-null value or use 'expression?' in the abstract grammar");
		this.condition = (Expression) condition;

        this.cierto = castList(cierto, unwrapIfContext.andThen(Statement.class::cast));
        this.falso = castList(falso, unwrapIfContext.andThen(Statement.class::cast));
		updatePositions(condition, cierto, falso);
	}


    // ----------------------------------
    // If: statement -> condition:expression cierto:statement* falso:statement*

	// Child 'condition:expression' 

	public void setCondition(Expression condition) {
		if (condition == null)
			throw new IllegalArgumentException("Parameter 'condition' can't be null. Pass a non-null value or use 'expression?' in the abstract grammar");
		this.condition = condition;

	}

    public Expression getCondition() {
        return condition;
    }


	// Child 'cierto:statement*' 

	public void setCierto(List<Statement> cierto) {
		if (cierto == null)
			cierto = new ArrayList<>();
		this.cierto = cierto;

	}

    public List<Statement> getCierto() {
        return cierto;
    }

    public Stream<Statement> cierto() {
        return cierto.stream();
    }


	// Child 'falso:statement*' 

	public void setFalso(List<Statement> falso) {
		if (falso == null)
			falso = new ArrayList<>();
		this.falso = falso;

	}

    public List<Statement> getFalso() {
        return falso;
    }

    public Stream<Statement> falso() {
        return falso.stream();
    }


    // ----------------------------------
    // Helper methods

    @Override
    public Object accept(Visitor v, Object param) {
        return v.visit(this, param);
    }

    @Override
    public String toString() {
        return "If{" + " condition=" + this.getCondition() + " cierto=" + this.getCierto() + " falso=" + this.getFalso() + "}";
    }


    // %% User Members -------------------------

        // Methods/attributes in this section will be preserved. Delete if not needed

    // %% --------------------------------------
}
