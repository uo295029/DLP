// Generated with VGen 2.0.0

package ast.statement;

import ast.expression.*;
import ast.definition.*;
import java.util.List;
import java.util.ArrayList;
import java.util.stream.Stream;
import visitor.Visitor;

// %% User Declarations -------------

    // Declarations (e.g. imports) in this section will be preserved. Delete if not needed

// %% -------------------------------

/*
	Println: statement -> exp:expression*
	statement -> 
	
	PHASE TypeChecking
	statement -> functionDefinition:functionDefinition
*/
public class Println extends AbstractStatement  {

    // ----------------------------------
    // Instance Variables

	// Println: statement -> exp:expression*
	private List<Expression> exp;

    // ----------------------------------
    // Constructors

	public Println(List<Expression> exp) {
		super();

		if (exp == null)
			exp = new ArrayList<>();
		this.exp = exp;

		updatePositions(exp);
	}

	public Println(Object exp) {
		super();

        this.exp = castList(exp, unwrapIfContext.andThen(Expression.class::cast));
		updatePositions(exp);
	}


    // ----------------------------------
    // Println: statement -> exp:expression*

	// Child 'exp:expression*' 

	public void setExp(List<Expression> exp) {
		if (exp == null)
			exp = new ArrayList<>();
		this.exp = exp;

	}

    public List<Expression> getExp() {
        return exp;
    }

    public Stream<Expression> exp() {
        return exp.stream();
    }


    // ----------------------------------
    // Helper methods

    @Override
    public Object accept(Visitor v, Object param) {
        return v.visit(this, param);
    }

    @Override
    public String toString() {
        return "Println{" + " exp=" + this.getExp() + "}";
    }


    // %% User Members -------------------------

        // Methods/attributes in this section will be preserved. Delete if not needed

    // %% --------------------------------------
}
