// Generated with VGen 2.0.0

package ast.definition;

import ast.*;

// %% User Declarations -------------

    // Declarations (e.g. imports) in this section will be preserved. Delete if not needed

// %% -------------------------------

/*
	definition -> 
*/
public abstract class AbstractDefinition extends AbstractAST implements Definition {




    // %% User Members -------------------------

        // Methods/attributes in this section will be preserved. Delete if not needed

    // %% --------------------------------------
}
