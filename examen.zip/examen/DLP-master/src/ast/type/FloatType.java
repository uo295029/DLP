// Generated with VGen 2.0.0

package ast.type;

import org.antlr.v4.runtime.Token;
import visitor.Visitor;

// %% User Declarations -------------

    // Declarations (e.g. imports) in this section will be preserved. Delete if not needed

// %% -------------------------------

/*
	FloatType: type -> 
	type -> 
	
	PHASE MemoryAllocation
	type -> suffix:string
*/
public class FloatType extends AbstractType  {



    // ----------------------------------
    // Helper methods

    @Override
    public Object accept(Visitor v, Object param) {
        return v.visit(this, param);
    }

    @Override
    public String toString() {
        return "FloatType{" + "}";
    }


    // %% User Members -------------------------

    @Override
    public int getNumberOfBytes() {
        return 4;
    }

    @Override
    public String getSuffix() {
        return "f";
    }

    // %% --------------------------------------
}
