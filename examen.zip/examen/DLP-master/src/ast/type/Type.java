// Generated with VGen 2.0.0

package ast.type;

import ast.*;
import org.antlr.v4.runtime.Token;

// %% User Declarations -------------

    // Declarations (e.g. imports) in this section will be preserved. Delete if not needed

// %% -------------------------------

/*
	type -> 
	
	PHASE MemoryAllocation
	type -> suffix:string
*/
public interface Type extends AST {




    // --------------------------------
    // PHASE MemoryAllocation

	// Attribute 'suffix:string' 

	public void setSuffix(String suffix);
	public String getSuffix();


    // %% User Members -------------------------

    public int getNumberOfBytes();

    // %% --------------------------------------
}
