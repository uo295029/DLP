// Generated with VGen 2.0.0

package ast.type;

import ast.*;
import org.antlr.v4.runtime.Token;

// %% User Declarations -------------

    // Declarations (e.g. imports) in this section will be preserved. Delete if not needed

// %% -------------------------------

/*
	type -> 
	
	PHASE MemoryAllocation
	type -> suffix:string
*/
public abstract class AbstractType extends AbstractAST implements Type {

    // ----------------------------------
    // Instance Variables


    // PHASE MemoryAllocation
	private String suffix;



    // --------------------------------
    // PHASE MemoryAllocation

	// Attribute 'suffix:string' 

	public void setSuffix(String suffix) {
		if (suffix == null)
			throw new IllegalArgumentException("Parameter 'suffix' can't be null. Pass a non-null value or use 'string?' in the abstract grammar");
		this.suffix = suffix;

	}

    public String getSuffix() {
        return suffix;
    }



    // %% User Members -------------------------

    public int getNumberOfBytes() {
        return -1;
    }

    // %% --------------------------------------
}
