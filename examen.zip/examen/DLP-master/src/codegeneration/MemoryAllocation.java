package codegeneration;

import ast.*;
import ast.definition.FunctionDefinition;
import ast.definition.StructDefinition;
import ast.definition.VarDefinition;
import visitor.DefaultVisitor;

// This class will be implemented in memory allocation phase

public class MemoryAllocation extends DefaultVisitor {
    int currentAddress = 0;
    int localAddress = 0;

    public void process(AST ast) {
        ast.accept(this, null);
    }

    @Override
    public Object visit(VarDefinition varDefinition, Object param) {
        super.visit(varDefinition,param);
        switch (varDefinition.getScope()) {
            case 0:
                varDefinition.setOffset(currentAddress);
                currentAddress += varDefinition.getType().getNumberOfBytes();
                break;
            case 2:
                localAddress += varDefinition.getType().getNumberOfBytes();
                varDefinition.setOffset(-localAddress);
                break;
        }
        return null;
    }

    @Override
    public Object visit(StructDefinition structDefinition, Object param) {
        int address = 0;
        super.visit(structDefinition,param);
        for (Field field : structDefinition.getFields()) {
            field.setOffset(address);
            address += field.getFieldType().getNumberOfBytes();
        }
        return null;
    }

    @Override
    public Object visit(FunctionDefinition functionDefinition, Object param) {
        localAddress = 0;
        int n = 4;
        int localsSize = 0;
        super.visit(functionDefinition,param);
        for (int i=functionDefinition.getParams().size()-1; i>=0; i--) {
            functionDefinition.getParams().get(i).setOffset(n);
            n+= functionDefinition.getParams().get(i).getType().getNumberOfBytes();
        }
        for (VarDefinition def : functionDefinition.getLocalVars()) {
            localsSize += def.getType().getNumberOfBytes();
        }
        functionDefinition.setLocalVarsSize(localsSize);
        functionDefinition.setParamsSize(n-4);
        return null;
    }



}
