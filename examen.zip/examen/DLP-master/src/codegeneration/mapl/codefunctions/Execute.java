// Generated with VGen 2.0.0

package codegeneration.mapl.codefunctions;

import ast.definition.FunctionDefinition;
import ast.expression.Expression;
import ast.statement.*;
import ast.type.VoidType;
import codegeneration.mapl.*;


public class Execute extends AbstractCodeFunction {

	int labels = 0;

    public Execute(MaplCodeSpecification specification) {
        super(specification);
    }


	// class Assignment(Expression left, Expression right)
	// phase TypeChecking { FunctionDefinition functionDefinition }

	/**
	 * execute ⟦Assignment:statement → left:expression right:expression⟧ =
	 * 	  Address[[left]]
	 *    Value[[right]]
	 *    Store<left.type>

	 */
	@Override
	public Object visit(Assignment assignment, Object param) {
		out("#LINE " + assignment.end().getLine());
		address(assignment.getLeft());
		value(assignment.getRight());
		out("store" + assignment.getLeft().getType().getSuffix());
		return null;
	}

	/**
	 * execute[[funcDefinition: statement -> name type scope statements:statement*]]() =
	 *          name <:>
	 *          <enter> ΣvarLocales.type.numberOfBytes
	 *          for( Statement s : statements)
	 *              execute[[s]]()
	 *          if (f.type instanceof Void)
	 *              <ret> 0 <,>
	 *                  funcDefinition.localVarsBytes() <,>
	 *                  funcDefinition.type.paramsBytes()
	 */
	@Override
	public Object visit(FunctionDefinition functionDefinition, Object param) {
		out("#LINE " + functionDefinition.start().getLine());
		out("\t" + functionDefinition.getName() + ":");
		out("enter " + functionDefinition.getLocalVarsSize());
		for (Statement statement : functionDefinition.getStatements()) {
			execute(statement);
		}
		if (functionDefinition.getType() instanceof VoidType) {
			out("ret\t" + 0 + "," + functionDefinition.getLocalVarsSize() + "," + functionDefinition.getParamsSize());
		}

		return null;
	}

	/**
	 * execute[[FunctionInvocation : statement -> function:expression arguments:expression*]]() =
	 *      arguments.forEach(exp -> value[[exp]])
	 *      call function.name
	 *      if(!statement.definition.type instanceof Void){
	 *          <pop> (statement.definition.type.suffix()
	 *      }
	 */
	@Override
	public Object visit(FunctionCallStatement functionCallStatement, Object param) {
		out("#LINE " + functionCallStatement.end().getLine());
		for (Expression expression: functionCallStatement.getParams()) {
			value(expression);
		}
		out("call " + functionCallStatement.getName());
		if (!(functionCallStatement.getFunctionDefinition().getType() instanceof VoidType)) {
			out("pop" + functionCallStatement.getFunctionDefinition().getType().getSuffix());
		}

		return null;
	}

	// class Print(List<Expression> exp)
	// phase TypeChecking { FunctionDefinition functionDefinition }

	/**
	 * execute ⟦Print:statement → exp:expression*⟧ =
	 *     foreach expression in exp:
	 *         value⟦expression⟧
	 *         OUT<expression.type>
	 */
	@Override
	public Object visit(Print print, Object param) {
		out("#LINE " + print.end().getLine());
		for (Expression expression : print.getExp()) {
			value(expression);
			out("out"+ expression.getType().getSuffix());
		}
		return null;
	}

	// class Printsp(List<Expression> exp)
	// phase TypeChecking { FunctionDefinition functionDefinition }

	/**
	 * execute ⟦Printsp:statement → exp:expression*⟧ =
	 *     foreach expression in exp:
	 *         value⟦expression⟧
	 *         OUT<expression.type>
	 *         OUT<"\t">
	 */
	@Override
	public Object visit(Printsp printsp, Object param) {
		out("#LINE " + printsp.end().getLine());
		if (printsp.getExp().isEmpty()) {
			out("pushb 9");
			out("outb");
		}
		for (Expression expression : printsp.getExp()) {
			value(expression);
			out("out"+ expression.getType().getSuffix());
			out("pushb 9");
			out("outb");
		}

		return null;
	}

	// class Println(List<Expression> exp)
	// phase TypeChecking { FunctionDefinition functionDefinition }
	/**
	 * execute ⟦Println:statement → exp:expression*⟧ =
	 *     foreach expression in exp:
	 *         value⟦expression⟧
	 *         OUT<expression.type>
	 *     	   OUT<"\n">
	 */
	@Override
	public Object visit(Println println, Object param) {
		out("#LINE " + println.end().getLine());
		if (println.getExp().isEmpty()) {
			out("pushb 10");
			out("outb");
		}
		for (Expression expression : println.getExp()) {
			value(expression);
			out("out"+ expression.getType().getSuffix());
			out("pushb 10");
			out("outb");
		}


		return null;
	}

	/**
	 * execute[[read: statement -> expression*]]() =
	 *          for (Expression expr : expression*)
	 *              address[[expr]]()
	 *              <in>expr.type.suffix()
	 *              <store>expr.type.suffix()
	 */
	@Override
	public Object visit(Read read, Object param) {
		out("#LINE " + read.end().getLine());

		address(read.getExpression());
		out("in" + read.getExpression().getType().getSuffix());
		out("store" + read.getExpression().getType().getSuffix());

		return null;
	}

	/**
	 * execute[return-> expression]
	 *     valor[exp]
	 *     ret *,*,*
	 *
	 */
	@Override
	public Object visit(Return returnValue, Object param) {
		out("#LINE " + returnValue.end().getLine());
		Expression exp = null;
		if (returnValue.getExpression().isPresent()) {
			exp = returnValue.getExpression().get();
		}
		if (exp != null) {
			value(exp);
			out("ret\t" + exp.getType().getNumberOfBytes() + "," +
					returnValue.getFunctionDefinition().getLocalVarsSize() + "," +
					returnValue.getFunctionDefinition().getParamsSize());
		}
		else {
			out("ret\t" + 0 + "," +
					returnValue.getFunctionDefinition().getLocalVarsSize() + "," +
					returnValue.getFunctionDefinition().getParamsSize());
		}

		return null;
	}

	/**
	 * execute[[IfStatement:st -> exp stCierto* stFalso*]]() =
	 *     int falseLabel = cg.getLabel();
	 *     int end = cg.getLabel();
	 *     value[[expression]]()
	 *     <jz label> falseLabel
	 *     for (Statement st : stCierto*)
	 *         execute[[st]]()
	 *     <jmp label> end
	 *     <label> falseLabel <:>
	 *     for (Statement st : stFalso*)
	 * 	      execute[[st]]()
	 * 	   <label> end <:>
	 */
	@Override
	public Object visit(If ifValue, Object param) {
		String falseLabel = "label" + getLabel();
		String endLabel = "label" + getLabel();
		out("#LINE " + ifValue.getCondition().end().getLine());
		value(ifValue.getCondition());
		out("jz " + falseLabel);
		for (Statement statement : ifValue.getCierto()) {
			execute(statement);
		}
		out("jmp " + endLabel);
		out(falseLabel + ":");
		for (Statement statement: ifValue.getFalso()) {
			execute(statement);
		}
		out(endLabel + ":");
		return null;
	}

	/**
	 * execute[[WhileStatement:st -> exp st*]]() =
	 *     int condition = cg.getLabel();
	 *     int end = cg.getLabel();
	 *     <label> condition <:>
	 *     value[[expression]]()
	 *     <jz label> end
	 *     for (Statement st : st*)
	 *         execute[[st]]()
	 *     <jmp label> condition
	 *     <label> end <:>
	 */
	@Override
	public Object visit(While whileValue, Object param) {
		String condition = "label" + getLabel();
		String end = "label" + getLabel();
		out(condition + ":");
		out("#LINE " + whileValue.getCondition().end().getLine());
		value(whileValue.getCondition());
		out("jz " + end);
		for (Statement statement : whileValue.getStatements()) {
			execute(statement);
		}
		out("jmp " + condition);
		out(end + ":");

		return null;
	}

	private int getLabel() {
		labels++;
		return labels;
	}

}
