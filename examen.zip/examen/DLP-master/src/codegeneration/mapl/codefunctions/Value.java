// Generated with VGen 2.0.0

package codegeneration.mapl.codefunctions;

import ast.expression.*;
import ast.type.CharType;
import ast.type.FloatType;
import ast.type.IntType;
import codegeneration.mapl.*;

import java.util.HashMap;
import java.util.Map;


public class Value extends AbstractCodeFunction {

	private Map<String, String> instruccion = new HashMap<>();
    public Value(MaplCodeSpecification specification) {
        super(specification);

		instruccion.put("+", "add");
		instruccion.put("-", "sub");
		instruccion.put("*", "mul");
		instruccion.put("/", "div");
		instruccion.put("%", "mod");

		instruccion.put("&&", "and");
		instruccion.put("||", "or");
		instruccion.put("!", "not");

		instruccion.put(">", "gt");
		instruccion.put("<", "lt");
		instruccion.put(">=", "ge");
		instruccion.put("<=", "le");
		instruccion.put("==", "eq");
		instruccion.put("!=", "ne");


    }


	// class Variable(String name)
	// phase Identification { VarDefinition varDefinition }
	// phase TypeChecking { Type type, boolean lvalue }
	@Override
	public Object visit(Variable variable, Object param) {

		address(variable);
		out("load" + variable.getType().getSuffix());

		return null;
	}

	// class FunctionCallExpression(String name, List<Expression> params)
	// phase Identification { FunctionDefinition functionDefinition }
	// phase TypeChecking { Type type, boolean lvalue }

	/**
	 * value ⟦FunctionCallExpression:expression → name:string params:expression*⟧ =
	 *    for (expression in params) {
	 *        value(expression)
	 *    <call> name
	 */
	@Override
	public Object visit(FunctionCallExpression functionCallExpression, Object param) {

		for (Expression expression:functionCallExpression.getParams()) {
			value(expression);
		}
		out("call " + functionCallExpression.getName());

		return null;
	}

	// class IntConstant(String value)
	// phase TypeChecking { Type type, boolean lvalue }

	/**
	 * value ⟦IntConstant:expression → value:string⟧ =
	 *       PUSHI {value}
	 */
	@Override
	public Object visit(IntConstant intConstant, Object param) {

		out("pushi " + intConstant.getValue());
		return null;
	}

	// class FloatConstant(String value)
	// phase TypeChecking { Type type, boolean lvalue }

	/**
	 * value ⟦FloatConstant:expression → value:string⟧ =
	 *      PUSHF {value}
	 */
	@Override
	public Object visit(FloatConstant floatConstant, Object param) {

		out("pushf " + floatConstant.getValue());
		return null;
	}

	// class CharConstant(String value)
	// phase TypeChecking { Type type, boolean lvalue }

	/**
	 * value ⟦CharConstant:expression → value:string⟧ =
	 *     PUSHB {value}
	 */
	@Override
	public Object visit(CharConstant charConstant, Object param) {
		String valor = charConstant.getValue().split("'")[1];
		if (valor.equalsIgnoreCase("\\n"))
			out("pushb 10"); // Caso especial
		else if (valor.equalsIgnoreCase("\\t"))
			out("pushb 9");
		else
			out("pushb " + valor.hashCode());
		return null;
	}

	// class ArithmeticExpression(Expression left, String op, Expression right)
	// phase TypeChecking { Type type, boolean lvalue }

	/**
	 * value ⟦ArithmeticExpression:expression → left:expression op:string right:expression⟧ =
	 *       value⟦left⟧
	 *       value⟦right⟧
	 *      if op == "+"
	 *          ADD< ArithmeticExpression.type.suffix>
	 *      if op == "-"
	 *          SUB< ArithmeticExpression.type.suffix >
	 *      if op == "*"
	 *          MUL< ArithmeticExpression.type.suffix >
	 *      if op == "/"
	 *          DIV< ArithmeticExpression.type.suffix >
	 *      if op == "%"
	 *          MOD< ArithmeticExpression.type.suffix >
	 */
	@Override
	public Object visit(ArithmeticExpression arithmeticExpression, Object param) {

		value(arithmeticExpression.getLeft());
		value(arithmeticExpression.getRight());
		out(instruccion.get(arithmeticExpression.getOp()) + arithmeticExpression.getType().getSuffix());

		return null;
	}

	// class ComparationExpression(Expression left, String op, Expression right)
	// phase TypeChecking { Type type, boolean lvalue }

	/**
	 * value ⟦ComparationExpression:expression → left:expression op:string right:expression⟧ =
	 *        value⟦left⟧
	 *       value⟦right⟧
	 *      if op == ">"
	 *          GT< ComparationExpression.type.suffix >
	 *      if op == "<"
	 *          LT< ComparationExpression.type.suffix >
	 *      if op == ">="
	 *          GE< ComparationExpression.type.suffix >
	 *      if op == "<="
	 *          LE< ComparationExpression.type.suffix >
	 *      if op == "=="
	 *          EQ< ComparationExpression.type.suffix >
	 *      if op == "!="
	 *          NE< ComparationExpression.type.suffix >
	 */
	@Override
	public Object visit(ComparationExpression comparationExpression, Object param) {

		value(comparationExpression.getLeft());
		value(comparationExpression.getRight());
		out(instruccion.get(comparationExpression.getOp()) + comparationExpression.getLeft().getType().getSuffix());

		return null;
	}

	// class LogicalExpression(Expression left, String op, Expression right)
	// phase TypeChecking { Type type, boolean lvalue }

	/**
	 * value ⟦LogicalExpression:expression → left:expression op:string right:expression⟧ =
	 *       value⟦left⟧
	 *       value⟦right⟧
	 *      if op == "&&"
	 *          AND< LogicalExpression.type.suffix >
	 *      if op == "||"
	 *          OR< LogicalExpression.type.suffix >
	 */
	@Override
	public Object visit(LogicalExpression logicalExpression, Object param) {

		value(logicalExpression.getLeft());
		value(logicalExpression.getRight());
		out(instruccion.get(logicalExpression.getOp()));

		return null;
	}

	// class AccessExpression(Expression left, String right)
	// phase TypeChecking { Type type, boolean lvalue }

	/**
	 * value ⟦AccessExpression:expression → left:expression right:string⟧ =
	 *         address[expression]
	 *         LOAD <expression.type.suffix>
	 */
	@Override
	public Object visit(AccessExpression accessExpression, Object param) {

		address(accessExpression);
		out("load" + accessExpression.getType().getSuffix());
		return null;
	}

	// class ArrayExpression(Expression left, Expression right)
	// phase TypeChecking { Type type, boolean lvalue }

	/**
	 * value ⟦ArrayExpression:expression → left:expression right:expression⟧ =
	 *        address[expression]
	 *         LOAD <expression.type.suffix>
	 */
	@Override
	public Object visit(ArrayExpression arrayExpression, Object param) {

		address(arrayExpression);
		out("load" + arrayExpression.getType().getSuffix());
		return null;
	}

	// class NotExpression(Expression expression)
	// phase TypeChecking { Type type, boolean lvalue }

	/**
	 * value ⟦NotExpression:expression → expression⟧ =
	 *        value[expression]
	 *        NOT < NotExpression.type.suffix >
	 */
	@Override
	public Object visit(NotExpression notExpression, Object param) {

		value(notExpression.getExpression());
		out("not");
		return null;
	}

	// class Cast(Type castType, Expression expression)
	// phase TypeChecking { Type type, boolean lvalue }
	@Override
	public Object visit(Cast cast, Object param) {

		value(cast.getExpression());
		if (cast.getExpression().getType() instanceof IntType) {
			if (cast.getCastType() instanceof CharType) {
				out("i2b");
			}
			else if (cast.getCastType() instanceof FloatType) {
				out("i2f");
			}
		}
		else if (cast.getExpression().getType() instanceof CharType) {
			if (cast.getCastType() instanceof IntType) {
				out("b2i");
			}
			else if (cast.getCastType() instanceof FloatType) {
				out("b2i");
				out("i2f");
			}
		}
		else if (cast.getExpression().getType() instanceof FloatType) {
			if (cast.getCastType() instanceof IntType) {
				out("f2i");
			}
			else if (cast.getCastType() instanceof CharType) {
				out("f2i");
				out("i2b");
			}
		}

		return null;
	}

}
