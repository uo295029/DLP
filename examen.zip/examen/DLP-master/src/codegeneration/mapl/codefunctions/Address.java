// Generated with VGen 2.0.0

package codegeneration.mapl.codefunctions;

import ast.expression.*;
import ast.type.StructType;
import codegeneration.mapl.*;


public class Address extends AbstractCodeFunction {

    public Address(MaplCodeSpecification specification) {
        super(specification);
    }


	// class Variable(String name)
	// phase Identification { VarDefinition varDefinition }
	// phase TypeChecking { Type type, boolean lvalue }
	/**
	 * address[[variable: expr -> ID]]() =
	 * if( expr.definition.scope == 0){
	 * <pusha> expr.definition.offset
	 * }else{
	 * <pusha bp>
	 * <pushi> expr.definition.offset
	 * <addi>
	 * }
	 */
	@Override
	public Object visit(Variable variable, Object param) {

		if (variable.getVarDefinition().getScope() == 0) {
			out("pusha " + variable.getVarDefinition().getOffset());
		}
		else {
			out("pusha BP");
			out("pushi " + variable.getVarDefinition().getOffset());
			out("addi");
		}

		return null;
	}

	// class AccessExpression(Expression left, String right)
	// phase TypeChecking { Type type, boolean lvalue }

	/**
	 * address ⟦AccessExpression:expression → left:expression right:string⟧ =
	 *        address[left]
	 *        pushi {left.type.definition.getField(right).offset}
	 *        addi
	 */
	@Override
	public Object visit(AccessExpression accessExpression, Object param) {
		address(accessExpression.getLeft());
		out("pushi " + ((StructType)accessExpression.getLeft().getType()).getStructDefinition()
				.getField(accessExpression.getRight()).getOffset());
		out("addi");

		return null;
	}

	// class ArrayExpression(Expression left, Expression right)
	// phase TypeChecking { Type type, boolean lvalue }

	/**
	 * address ⟦ArrayExpression:expression → left:expression right: expression⟧ =
	 *        address[left]
	 *        value [right]
	 *        pushi {expression.type.numberOfBytes}
	 *        muli
	 *        addi
	 */
	@Override
	public Object visit(ArrayExpression arrayExpression, Object param) {

		address(arrayExpression.getLeft());
		value(arrayExpression.getRight());
		out("pushi " + arrayExpression.getType().getNumberOfBytes());
		out("muli");
		out("addi");

		return null;
	}

}
